package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.math.Rectangle;

public class MyGdxGame extends ApplicationAdapter {

	SpriteBatch batch;
	Texture img;
	Helicopter helicopter;


	static String[] hcTextures = new String[]{"heli1.png", "heli2.png", "heli3.png", "heli4.png"};

	@Override
	public void create () {

		batch = new SpriteBatch();
		helicopter = new Helicopter(hcTextures, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
	}

	@Override
	public void render () {
		ScreenUtils.clear(135/255f, 206/255f, 235/255f, 1);

		batch.begin();
		helicopter.render(batch);
		BitmapFont font = new BitmapFont(); //or use alex answer to use custom font
		font.getData().setScale(4,4);
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}

}
