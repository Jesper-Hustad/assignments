## TDT4165 - Programming Languages
# Assignment 1: Introduction to Oz
The assignment is compulsory and individual.  
Your delivery should contain a solution to tasks 3-5 and a valid attempt at tasks 6-8.


[Task 1](task1.oz)  
[Task 2](task2.oz)  
[Task 3](task3.oz)  
[Task 4](task4.oz)  
[Task 5](task5.oz)  
[Task 6](task6.oz)  
[Task 7](task7.oz)  
[Task 8](task8.oz)  